
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  imageUrl: string;
}

export enum OrderStatus {
  Processing = 'Processing',
  InTransit = 'In Transit',
  Delivered = 'Delivered',
  Cancelled = 'Cancelled'
}

export interface Order {
  id: string;
  customerName: string;
  status: OrderStatus;
  items: { productId: string; quantity: number }[];
  total: number;
  deliveryAddress: string;
  courierId?: string;
}

export interface Courier {
    id: string;
    name: string;
    vehicle: 'Van' | 'Motorcycle' | 'Truck';
    location: { lat: number; lng: number };
}

export interface Sentiment {
    consumerRating: number;
    courierRating: number;
    smbRating: number;
}

export enum MessageSender {
    User = 'user',
    AI = 'ai'
}

export interface GroundingSource {
    uri: string;
    title: string;
}

export interface ChatMessage {
    sender: MessageSender;
    text: string;
    sources?: GroundingSource[];
}
