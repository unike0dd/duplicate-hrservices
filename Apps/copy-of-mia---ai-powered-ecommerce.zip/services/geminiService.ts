
import { GoogleGenAI } from "@google/genai";
import type { GenerateContentResponse } from "@google/genai";
import type { ChatMessage, GroundingSource } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder key. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "placeholder_api_key" });

const model = 'gemini-2.5-flash';

const systemInstruction = `You are MIA, a helpful and friendly AI assistant for an advanced e-commerce platform. Your purpose is to assist both SMB owners and End Consumers. You have access to information about products, orders, deliveries, and business analytics. When a user asks you to find local businesses, restaurants, or services (e.g., "find coffee shops near me"), use your search tool to find them. You should specify a 10-mile radius in your search if the user doesn't provide one. After searching, present the top 4 options to the user. Be concise, professional, and emulate a helpful chatbot. When asked about order tracking, provide a simulated but realistic response. When asked for recommendations, suggest products from the mock data. Format your responses clearly, using markdown for lists or emphasis where appropriate.`;

const isSearchQuery = (message: string): boolean => {
    const keywords = ['find', 'search for', 'look for', 'where can i', 'shops', 'restaurants', 'businesses', 'services near', 'who has'];
    const lowerCaseMessage = message.toLowerCase();
    return keywords.some(keyword => lowerCaseMessage.includes(keyword));
};


export async function streamChatResponse(
    history: ChatMessage[], 
    newMessage: string
): Promise<AsyncGenerator<{ textChunk?: string; sources?: GroundingSource[] }, void, unknown>> {

    if (!process.env.API_KEY) {
        const mockResponse = "It looks like the AI service isn't configured. Please contact support. (To fix this, set your Gemini API key in the environment variables).";
        async function* mockStream(): AsyncGenerator<{ textChunk?: string; sources?: GroundingSource[] }, void, unknown> {
            for (const word of mockResponse.split(' ')) {
                await new Promise(resolve => setTimeout(resolve, 50));
                yield { textChunk: `${word} ` };
            }
        }
        return mockStream();
    }

    const useSearch = isSearchQuery(newMessage);

    const contents = history.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
    }));
    contents.push({ role: 'user', parts: [{ text: newMessage }] });

    const config: any = {
        systemInstruction: systemInstruction,
    };

    if (useSearch) {
        config.tools = [{googleSearch: {}}];
    }
    
    const responseStream = await ai.models.generateContentStream({
        model,
        contents,
        config,
    });

    async function* streamGenerator() {
        let aggregatedResponse: GenerateContentResponse | undefined;
        for await (const chunk of responseStream) {
            if (chunk.text) {
                yield { textChunk: chunk.text };
            }
            aggregatedResponse = chunk;
        }
        
        if (useSearch && aggregatedResponse) {
             const groundingMetadata = aggregatedResponse.candidates?.[0]?.groundingMetadata;
             if (groundingMetadata?.groundingChunks) {
                const sources: GroundingSource[] = groundingMetadata.groundingChunks
                    .map((chunk: any) => ({
                        uri: chunk.web?.uri || '',
                        title: chunk.web?.title || ''
                    }))
                    .filter(source => source.uri && source.title);
                
                if (sources.length > 0) {
                    yield { sources: sources };
                }
             }
        }
    }

    return streamGenerator();
}
