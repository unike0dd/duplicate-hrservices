
import React, { useState, useEffect, useCallback, useRef, FormEvent } from 'react';
import { HashRouter, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { Product, Order, ChatMessage } from './types';
import { OrderStatus, MessageSender } from './types';
import { streamChatResponse } from './services/geminiService';
import { MIAIcon, TruckIcon, InventoryIcon, OrdersIcon, AnalyticsIcon, SendIcon, CloseIcon, UserIcon, BusinessIcon, LinkIcon } from './components/Icons';

// --- MOCK DATA ---
const mockProducts: Product[] = [
  { id: 'p1', name: 'Premium Wireless Headphones', category: 'Electronics', price: 199.99, stock: 150, imageUrl: 'https://picsum.photos/seed/headphones/400/300' },
  { id: 'p2', name: 'Smart Fitness Tracker', category: 'Wearables', price: 89.99, stock: 250, imageUrl: 'https://picsum.photos/seed/tracker/400/300' },
  { id: 'p3', name: 'Ergonomic Office Chair', category: 'Furniture', price: 349.50, stock: 75, imageUrl: 'https://picsum.photos/seed/chair/400/300' },
  { id: 'p4', name: 'Organic Colombian Coffee Beans', category: 'Groceries', price: 22.00, stock: 500, imageUrl: 'https://picsum.photos/seed/coffee/400/300' },
  { id: 'p5', name: 'Professional DSLR Camera Kit', category: 'Electronics', price: 1250.00, stock: 30, imageUrl: 'https://picsum.photos/seed/camera/400/300' },
  { id: 'p6', name: 'Yoga Mat with Carrying Strap', category: 'Sports', price: 45.00, stock: 300, imageUrl: 'https://picsum.photos/seed/yoga/400/300' },
];

const mockOrders: Order[] = [
  { id: 'ORD-001', customerName: 'Alice Johnson', status: OrderStatus.InTransit, items: [{ productId: 'p1', quantity: 1 }], total: 199.99, deliveryAddress: '123 Maple St, Springfield', courierId: 'c1' },
  { id: 'ORD-002', customerName: 'Bob Williams', status: OrderStatus.Delivered, items: [{ productId: 'p4', quantity: 2 }, { productId: 'p6', quantity: 1 }], total: 89.00, deliveryAddress: '456 Oak Ave, Shelbyville' },
  { id: 'ORD-003', customerName: 'Charlie Brown', status: OrderStatus.Processing, items: [{ productId: 'p3', quantity: 1 }], total: 349.50, deliveryAddress: '789 Pine Ln, Capital City' },
  { id: 'ORD-004', customerName: 'Diana Prince', status: OrderStatus.InTransit, items: [{ productId: 'p2', quantity: 1 }], total: 89.99, deliveryAddress: '101 Gotham Rd, Metropolis', courierId: 'c2'},
];

const analyticsData = [
    { name: 'Jan', Sales: 4000, Expenses: 2400 },
    { name: 'Feb', Sales: 3000, Expenses: 1398 },
    { name: 'Mar', Sales: 2000, Expenses: 9800 },
    { name: 'Apr', Sales: 2780, Expenses: 3908 },
    { name: 'May', Sales: 1890, Expenses: 4800 },
    { name: 'Jun', Sales: 2390, Expenses: 3800 },
];

// --- HELPER & UI COMPONENTS ---

const StarRating = ({ rating }: { rating: number }) => (
    <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
            <svg key={i} className={`w-4 h-4 ${i < rating ? 'text-yellow-400' : 'text-gray-500'}`} fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.368 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118l-3.368-2.448a1 1 0 00-1.175 0l-3.368 2.448c-.784.57-1.838-.197-1.54-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.24 9.384c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z" />
            </svg>
        ))}
    </div>
);


const Header = () => {
    const location = useLocation();
    const getTitle = () => {
        switch(location.pathname){
            case '/smb-dashboard': return 'SMB Dashboard';
            case '/consumer': return 'Consumer Portal';
            default: return 'MIA AI Ecommerce';
        }
    };
    return (
        <header className="bg-gray-800/50 backdrop-blur-sm p-4 flex justify-between items-center border-b border-gray-700 sticky top-0 z-20">
            <Link to="/" className="flex items-center gap-3">
                <MIAIcon className="w-8 h-8 text-cyan-400"/>
                <h1 className="text-xl font-bold text-white tracking-tight">{getTitle()}</h1>
            </Link>
            <nav className="flex items-center gap-4">
                <Link to="/smb-dashboard" className={`text-sm font-medium ${location.pathname.startsWith('/smb') ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}>SMB Login</Link>
                <Link to="/consumer" className={`text-sm font-medium ${location.pathname === '/consumer' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}>Shop Now</Link>
            </nav>
        </header>
    );
};

const LoadingSpinner = () => (
    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
);

interface ChatModalProps {
    isOpen: boolean;
    onClose: () => void;
}
const ChatModal = ({ isOpen, onClose }: ChatModalProps) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { sender: MessageSender.AI, text: "Hello! I'm MIA, your personal shopping and business assistant. How can I help you today?" }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);
    
    useEffect(() => {
        if(isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'auto';
        }
        return () => { document.body.style.overflow = 'auto'; };
    }, [isOpen]);

    const handleSend = async (e: FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const userMessageText = input;
        const userMessage: ChatMessage = { sender: MessageSender.User, text: userMessageText };
        
        const historyForApi = [...messages];

        setMessages(prev => [...prev, userMessage, { sender: MessageSender.AI, text: '' }]);
        setInput('');
        setIsLoading(true);

        try {
            const stream = await streamChatResponse(historyForApi, userMessageText);
            
            for await (const chunk of stream) {
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];

                    if (chunk.textChunk) {
                        lastMessage.text += chunk.textChunk;
                    }
                    if (chunk.sources) {
                        lastMessage.sources = chunk.sources;
                    }
                    
                    return newMessages;
                });
            }
        } catch (error) {
            console.error("Error streaming response:", error);
            const errorMessage: ChatMessage = { sender: MessageSender.AI, text: "I'm sorry, I'm having trouble connecting. Please try again later." };
            setMessages(prev => [...prev.slice(0, -1), errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 p-4" onClick={onClose}>
            <div className="bg-gray-800 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-2xl h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-gray-700">
                    <div className="flex items-center gap-3">
                        <MIAIcon className="w-8 h-8 text-cyan-400" />
                        <h2 className="text-lg font-bold text-white">Chat with MIA</h2>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.sender === MessageSender.User ? 'justify-end' : 'justify-start'}`}>
                           {msg.sender === MessageSender.AI && <MIAIcon className="w-6 h-6 text-cyan-400 flex-shrink-0 self-start" />}
                           <div className={`max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${msg.sender === MessageSender.User ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-gray-700 text-gray-200 rounded-bl-none'}`}>
                               <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                               {msg.sources && msg.sources.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-cyan-500/20">
                                        <h4 className="text-xs font-semibold text-gray-400 mb-2">Sources:</h4>
                                        <div className="flex flex-col space-y-2">
                                            {msg.sources.map((source, i) => (
                                                <a 
                                                    key={i} 
                                                    href={source.uri} 
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                    className="flex items-center gap-2 text-xs text-cyan-400 hover:underline group"
                                                >
                                                    <LinkIcon className="w-3 h-3 flex-shrink-0" />
                                                    <span className="truncate group-hover:text-cyan-300 transition-colors">{source.title || source.uri}</span>
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                           </div>
                        </div>
                    ))}
                     {isLoading && messages[messages.length - 1]?.sender === MessageSender.AI && messages[messages.length - 1]?.text === '' && (
                        <div className="flex items-end gap-2 justify-start">
                           <MIAIcon className="w-6 h-6 text-cyan-400 flex-shrink-0" />
                           <div className="max-w-md lg:max-w-lg px-4 py-2 rounded-2xl bg-gray-700 text-gray-200 rounded-bl-none">
                                <div className="flex items-center gap-2">
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></span>
                                </div>
                           </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <form onSubmit={handleSend} className="p-4 border-t border-gray-700">
                    <div className="flex items-center gap-2 bg-gray-900 rounded-full border border-gray-600 focus-within:border-cyan-500 transition-colors">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Find restaurants near me..."
                            className="flex-1 bg-transparent px-4 py-2 text-white placeholder-gray-400 focus:outline-none"
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading || !input.trim()} className="p-2 text-white rounded-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all mr-1">
                            {isLoading ? <LoadingSpinner /> : <SendIcon className="w-5 h-5" />}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// --- PAGE COMPONENTS ---

const LandingPage = () => {
    const navigate = useNavigate();
    return (
        <div className="flex flex-col items-center justify-center min-h-screen text-center p-8 bg-gray-900 text-white">
            <div className="absolute inset-0 bg-grid-gray-700/[0.2] [mask-image:linear-gradient(to_bottom,white_5%,transparent_90%)]"></div>
            <div className="relative z-10">
                <MIAIcon className="w-24 h-24 text-cyan-400 mx-auto mb-6 animate-pulse" />
                <h1 className="text-5xl md:text-7xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-white to-cyan-400 pb-2">Welcome to MIA</h1>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-300">Your AI-Powered Ecommerce Co-pilot. Streamline dispatch, manage inventory, and delight customers—all in one place.</p>
                <div className="mt-12 flex flex-col md:flex-row gap-4 justify-center">
                    <button onClick={() => navigate('/smb-dashboard')} className="group flex items-center justify-center gap-3 bg-white text-gray-900 font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-cyan-400/30 transform hover:-translate-y-1 transition-all duration-300">
                        <BusinessIcon className="w-6 h-6 text-gray-900" />
                        SMB Owner Portal
                    </button>
                    <button onClick={() => navigate('/consumer')} className="group flex items-center justify-center gap-3 bg-cyan-600 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-cyan-400/50 transform hover:-translate-y-1 transition-all duration-300">
                        <UserIcon className="w-6 h-6 text-white" />
                        Consumer Shopping
                    </button>
                </div>
                <div className="mt-16 text-sm text-gray-500">
                    <p className="font-semibold">Security Compliance:</p>
                    <p className="mt-2 text-xs">AI Firewall | PCI DSS | NIST | CISA | PWA | CSP</p>
                </div>
            </div>
        </div>
    );
}

const SmbDashboardPage = () => {
    const [activeTab, setActiveTab] = useState('dispatch');
    const tabs = [
        { id: 'dispatch', label: 'Dispatch', icon: TruckIcon },
        { id: 'inventory', label: 'Inventory', icon: InventoryIcon },
        { id: 'orders', label: 'Orders', icon: OrdersIcon },
        { id: 'analytics', label: 'Analytics', icon: AnalyticsIcon },
    ];

    const renderTabContent = () => {
        switch (activeTab) {
            case 'dispatch':
                return (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-2 h-96 lg:h-[calc(100vh-12rem)] bg-gray-800 rounded-lg p-4 shadow-lg border border-gray-700">
                            <h3 className="text-lg font-bold mb-2">Live Dispatch Map</h3>
                            <div className="relative w-full h-full bg-gray-700 rounded-md overflow-hidden">
                               <img src="https://www.openstreetmap.org/export/embed.html?bbox=-74.01,40.70,-73.98,40.72" className="absolute inset-0 w-full h-full object-cover opacity-20" alt="map background"/>
                               <div className="absolute top-1/4 left-1/4 animate-pulse">
                                  <TruckIcon className="w-8 h-8 text-cyan-400" />
                                  <span className="absolute -top-6 -right-8 text-xs bg-gray-900 px-2 py-1 rounded">ORD-001</span>
                               </div>
                                <div className="absolute bottom-1/3 right-1/3 animate-pulse" style={{animationDelay: '0.5s'}}>
                                  <TruckIcon className="w-8 h-8 text-yellow-400" />
                                  <span className="absolute -top-6 -right-8 text-xs bg-gray-900 px-2 py-1 rounded">ORD-004</span>
                               </div>
                            </div>
                        </div>
                        <div className="h-96 lg:h-[calc(100vh-12rem)] overflow-y-auto bg-gray-800 rounded-lg p-4 shadow-lg border border-gray-700">
                           <h3 className="text-lg font-bold mb-4">Active Deliveries</h3>
                           <div className="space-y-4">
                                {mockOrders.filter(o => o.status === OrderStatus.InTransit).map(order => (
                                    <div key={order.id} className="bg-gray-700 p-3 rounded-lg">
                                        <p className="font-bold text-white">{order.id}</p>
                                        <p className="text-sm text-gray-300">{order.deliveryAddress}</p>
                                        <div className="flex justify-between items-center mt-2">
                                            <span className="text-xs font-medium bg-cyan-500/20 text-cyan-300 px-2 py-1 rounded-full">{order.status}</span>
                                            <button className="text-xs bg-gray-600 hover:bg-gray-500 px-2 py-1 rounded">Assign</button>
                                        </div>
                                    </div>
                                ))}
                           </div>
                        </div>
                    </div>
                );
            case 'inventory':
                 return (
                    <div className="bg-gray-800 rounded-lg shadow-lg border border-gray-700 overflow-hidden">
                         <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-300">
                                <thead className="text-xs text-gray-400 uppercase bg-gray-700">
                                    <tr>
                                        <th scope="col" className="px-6 py-3">Product Name</th>
                                        <th scope="col" className="px-6 py-3">Category</th>
                                        <th scope="col" className="px-6 py-3">Price</th>
                                        <th scope="col" className="px-6 py-3">Stock</th>
                                        <th scope="col" className="px-6 py-3">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockProducts.map((p) => (
                                        <tr key={p.id} className="bg-gray-800 border-b border-gray-700 hover:bg-gray-700/50">
                                            <th scope="row" className="px-6 py-4 font-medium text-white whitespace-nowrap">{p.name}</th>
                                            <td className="px-6 py-4">{p.category}</td>
                                            <td className="px-6 py-4">${p.price.toFixed(2)}</td>
                                            <td className="px-6 py-4">{p.stock}</td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${p.stock > 50 ? 'bg-green-500/20 text-green-300' : p.stock > 0 ? 'bg-yellow-500/20 text-yellow-300' : 'bg-red-500/20 text-red-300'}`}>
                                                    {p.stock > 50 ? 'In Stock' : p.stock > 0 ? 'Low Stock' : 'Out of Stock'}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                 );
            case 'orders':
                return (
                    <div className="bg-gray-800 rounded-lg shadow-lg border border-gray-700 overflow-hidden">
                         <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-300">
                                <thead className="text-xs text-gray-400 uppercase bg-gray-700">
                                    <tr>
                                        <th scope="col" className="px-6 py-3">Order ID</th>
                                        <th scope="col" className="px-6 py-3">Customer</th>
                                        <th scope="col" className="px-6 py-3">Status</th>
                                        <th scope="col" className="px-6 py-3">Total</th>
                                        <th scope="col" className="px-6 py-3">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockOrders.map((o) => (
                                        <tr key={o.id} className="bg-gray-800 border-b border-gray-700 hover:bg-gray-700/50">
                                            <th scope="row" className="px-6 py-4 font-medium text-white whitespace-nowrap">{o.id}</th>
                                            <td className="px-6 py-4">{o.customerName}</td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                                    o.status === OrderStatus.Delivered ? 'bg-green-500/20 text-green-300' :
                                                    o.status === OrderStatus.InTransit ? 'bg-cyan-500/20 text-cyan-300' :
                                                    o.status === OrderStatus.Processing ? 'bg-yellow-500/20 text-yellow-300' : 'bg-red-500/20 text-red-300'
                                                }`}>{o.status}</span>
                                            </td>
                                            <td className="px-6 py-4">${o.total.toFixed(2)}</td>
                                            <td className="px-6 py-4">
                                                <button className="font-medium text-cyan-400 hover:underline">Details</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            case 'analytics':
                 return (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
                            <h3 className="text-sm font-medium text-gray-400">Total Revenue</h3>
                            <p className="text-3xl font-bold text-white mt-2">$75,340.50</p>
                        </div>
                         <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
                            <h3 className="text-sm font-medium text-gray-400">Total Orders</h3>
                            <p className="text-3xl font-bold text-white mt-2">1,204</p>
                        </div>
                        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
                            <h3 className="text-sm font-medium text-gray-400">Customer Sentiment</h3>
                            <div className="flex justify-between items-center mt-2">
                                <p className="text-3xl font-bold text-white">4.8/5</p>
                                <StarRating rating={5} />
                            </div>
                        </div>
                         <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
                            <h3 className="text-sm font-medium text-gray-400">Courier Rating</h3>
                            <div className="flex justify-between items-center mt-2">
                               <p className="text-3xl font-bold text-white">4.9/5</p>
                               <StarRating rating={5} />
                            </div>
                        </div>
                        <div className="md:col-span-2 lg:col-span-4 bg-gray-800 p-6 rounded-lg border border-gray-700 h-96">
                             <h3 className="text-lg font-bold mb-4 text-white">Sales vs Expenses</h3>
                             <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={analyticsData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#374151"/>
                                    <XAxis dataKey="name" tick={{ fill: '#9CA3AF' }}/>
                                    <YAxis tick={{ fill: '#9CA3AF' }}/>
                                    <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}/>
                                    <Legend wrapperStyle={{ color: '#D1D5DB' }}/>
                                    <Bar dataKey="Sales" fill="#22d3ee" />
                                    <Bar dataKey="Expenses" fill="#facc15" />
                                 </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                 );
            default: return null;
        }
    };

    return (
        <div className="p-4 sm:p-6 lg:p-8 text-white min-h-screen">
            <div className="mb-6">
                <div className="border-b border-gray-700">
                    <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`${
                                    activeTab === tab.id
                                        ? 'border-cyan-400 text-cyan-400'
                                        : 'border-transparent text-gray-400 hover:text-white hover:border-gray-500'
                                } flex items-center gap-2 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors focus:outline-none`}
                            >
                                <tab.icon className="w-5 h-5"/>
                                {tab.label}
                            </button>
                        ))}
                    </nav>
                </div>
            </div>
            <div>{renderTabContent()}</div>
        </div>
    );
};


const ConsumerPortalPage = () => {
    const [cart, setCart] = useState<Map<string, number>>(new Map());
    const [isCartOpen, setIsCartOpen] = useState(false);

    const addToCart = (productId: string) => {
        setCart(prev => {
            const newCart = new Map(prev);
            newCart.set(productId, (newCart.get(productId) || 0) + 1);
            return newCart;
        });
        setIsCartOpen(true);
    };
    
    const cartItems = Array.from(cart.entries()).map(([productId, quantity]) => {
        const product = mockProducts.find(p => p.id === productId)!;
        return { ...product, quantity };
    });

    const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
    const taxes = subtotal * 0.08;
    const delivery = 5.99;
    const total = subtotal + taxes + delivery;

    return (
        <div className="p-4 sm:p-6 lg:p-8 text-white min-h-screen">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold">Featured Products</h2>
                 <button onClick={() => setIsCartOpen(true)} className="relative bg-gray-700 hover:bg-gray-600 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                    {cart.size > 0 && <span className="absolute -top-1 -right-1 bg-cyan-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">{cart.size}</span>}
                </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {mockProducts.map(product => (
                    <div key={product.id} className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700 shadow-lg group transition-all duration-300 hover:shadow-cyan-500/20 hover:border-cyan-500/50">
                        <img src={product.imageUrl} alt={product.name} className="w-full h-48 object-cover"/>
                        <div className="p-4">
                            <p className="text-sm text-gray-400">{product.category}</p>
                            <h3 className="font-bold text-lg mt-1 text-white">{product.name}</h3>
                            <div className="flex justify-between items-center mt-4">
                                <p className="text-xl font-semibold text-cyan-400">${product.price.toFixed(2)}</p>
                                <button onClick={() => addToCart(product.id)} className="bg-gray-700 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-cyan-600 transition-colors">Add to Cart</button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Cart Sidebar */}
            {isCartOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40" onClick={() => setIsCartOpen(false)}>
                    <div className="fixed top-0 right-0 h-full w-full max-w-md bg-gray-900 shadow-2xl flex flex-col border-l border-gray-700" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center p-4 border-b border-gray-700">
                             <h2 className="text-xl font-bold">Your Cart</h2>
                             <button onClick={() => setIsCartOpen(false)}><CloseIcon className="w-6 h-6 text-gray-400 hover:text-white"/></button>
                        </div>
                        {cartItems.length > 0 ? (
                        <>
                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                                {cartItems.map(item => (
                                    <div key={item.id} className="flex gap-4 items-center">
                                        <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-md"/>
                                        <div className="flex-1">
                                            <p className="font-semibold">{item.name}</p>
                                            <p className="text-sm text-gray-400">${item.price.toFixed(2)} x {item.quantity}</p>
                                        </div>
                                        <p className="font-bold text-lg">${(item.price * item.quantity).toFixed(2)}</p>
                                    </div>
                                ))}
                            </div>
                            <div className="p-4 border-t border-gray-700 space-y-2 text-sm">
                                <div className="flex justify-between"><span className="text-gray-400">Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Taxes</span><span>${taxes.toFixed(2)}</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Delivery</span><span>${delivery.toFixed(2)}</span></div>
                                <div className="flex justify-between text-lg font-bold mt-2 pt-2 border-t border-gray-600"><span className="text-white">Total</span><span className="text-cyan-400">${total.toFixed(2)}</span></div>
                                <button className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 rounded-lg mt-4 transition-colors">Proceed to Checkout</button>
                            </div>
                        </>
                        ) : (
                            <div className="flex-1 flex flex-col items-center justify-center text-center p-4">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                                <p className="mt-4 text-lg font-semibold">Your cart is empty</p>
                                <p className="text-gray-400 text-sm">Add some products to get started.</p>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};


// --- MAIN APP COMPONENT ---

export default function App() {
    const [isChatOpen, setChatOpen] = useState(false);

    return (
        <HashRouter>
            <div className="bg-gray-900 text-gray-100 min-h-screen">
                <LocationAwareHeader />
                <main>
                    <Routes>
                        <Route path="/" element={<LandingPage />} />
                        <Route path="/smb-dashboard" element={<SmbDashboardPage />} />
                        <Route path="/consumer" element={<ConsumerPortalPage />} />
                    </Routes>
                </main>
                <div className="fixed bottom-6 right-6 z-40">
                    <button onClick={() => setChatOpen(true)} className="bg-cyan-500 hover:bg-cyan-400 text-white w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transform hover:scale-110 transition-all duration-300">
                        <MIAIcon className="w-9 h-9" />
                    </button>
                </div>
                <ChatModal isOpen={isChatOpen} onClose={() => setChatOpen(false)} />
            </div>
        </HashRouter>
    );
}

// A helper component to render the header only on non-landing pages
const LocationAwareHeader = () => {
    const location = useLocation();
    if (location.pathname === '/') {
        return null;
    }
    return <Header />;
}
