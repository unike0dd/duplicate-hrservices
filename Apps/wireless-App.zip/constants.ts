
import { Product } from './types';

export const TAX_RATE = 0.085; // 8.5%
export const DELIVERY_FEE = 5.00;

export const MOCK_PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Artisan Sourdough',
    name_es: 'Pan de Masa Madre Artesanal',
    description: 'A crusty, chewy loaf of naturally leavened sourdough bread, perfect for sandwiches or toast.',
    description_es: 'Una hogaza de pan de masa madre de fermentación natural, crujiente y masticable, perfecta para sándwiches o tostadas.',
    price: 8.50,
    imageUrl: 'https://picsum.photos/seed/sourdough/400/300',
    stock: 20,
  },
  {
    id: 2,
    name: 'Espresso Beans',
    name_es: 'Granos de Espresso',
    description: 'A 12oz bag of single-origin espresso beans with notes of chocolate and cherry.',
    description_es: 'Una bolsa de 12oz de granos de espresso de origen único con notas de chocolate y cereza.',
    price: 16.00,
    imageUrl: 'https://picsum.photos/seed/coffee/400/300',
    stock: 50,
  },
  {
    id: 3,
    name: 'Handmade Pottery Mug',
    name_es: 'Taza de Cerámica Hecha a Mano',
    description: 'A unique, handcrafted ceramic mug, perfect for your morning coffee. Holds 14oz.',
    description_es: 'Una taza de cerámica única, hecha a mano, perfecta para tu café de la mañana. Capacidad de 14oz.',
    price: 24.00,
    imageUrl: 'https://picsum.photos/seed/mug/400/300',
    stock: 15,
  },
  {
    id: 4,
    name: 'Gourmet Olive Oil',
    name_es: 'Aceite de Oliva Gourmet',
    description: 'A 500ml bottle of cold-pressed extra virgin olive oil from Italy. Fruity and robust.',
    description_es: 'Una botella de 500ml de aceite de oliva virgen extra prensado en frío de Italia. Afrutado y robusto.',
    price: 18.75,
    imageUrl: 'https://picsum.photos/seed/oliveoil/400/300',
    stock: 30,
  },
  {
    id: 5,
    name: 'Organic Honey',
    name_es: 'Miel Orgánica',
    description: 'A jar of raw, unfiltered wildflower honey from local beekeepers. Sweet and floral.',
    description_es: 'Un frasco de miel cruda y sin filtrar de flores silvestres de apicultores locales. Dulce y floral.',
    price: 12.00,
    imageUrl: 'https://picsum.photos/seed/honey/400/300',
    stock: 40,
  },
  {
    id: 6,
    name: 'Dark Chocolate Bar',
    name_es: 'Barra de Chocolate Oscuro',
    description: 'A 72% cacao dark chocolate bar with sea salt. Rich and satisfying.',
    description_es: 'Una barra de chocolate oscuro 72% cacao con sal marina. Rico y satisfactorio.',
    price: 6.50,
    imageUrl: 'https://picsum.photos/seed/chocolate/400/300',
    stock: 100,
  },
  {
    id: 7,
    name: 'Gourmet Jam',
    name_es: 'Mermelada Gourmet',
    description: 'Small-batch strawberry and rhubarb jam. Perfect for toast or scones.',
    description_es: 'Mermelada de fresa y ruibarbo en lotes pequeños. Perfecta para tostadas o scones.',
    price: 9.00,
    imageUrl: 'https://picsum.photos/seed/jam/400/300',
    stock: 25,
  },
  {
    id: 8,
    name: 'Vintage Bicycle Bell',
    name_es: 'Timbre de Bicicleta Vintage',
    description: 'A classic brass bicycle bell with a clear, resonant ring. Fits all standard handlebars.',
    description_es: 'Un timbre de bicicleta clásico de latón con un sonido claro y resonante. Se adapta a todos los manillares estándar.',
    price: 15.50,
    imageUrl: 'https://picsum.photos/seed/bicycle/400/300',
    stock: 18,
  }
];
