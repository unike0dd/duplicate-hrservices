
import React from 'react';
import { Product, TranslationSet } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { MinusIcon } from './icons/MinusIcon';

interface ProductCardProps {
  product: Product;
  cartQuantity: number;
  onAddItem: (product: Product) => void;
  onRemoveItem: (product: Product) => void;
  t: TranslationSet;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, cartQuantity, onAddItem, onRemoveItem, t }) => {
  const canAdd = cartQuantity < product.stock;

  return (
    <div className="flex-shrink-0 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
      <img className="w-full h-40 object-cover" src={product.imageUrl} alt={product.name} />
      <div className="p-4 flex flex-col justify-between h-48">
        <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white truncate">{product.name}</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">{`$${product.price.toFixed(2)}`}</p>
        </div>
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => onRemoveItem(product)}
              disabled={cartQuantity === 0}
              className="p-1.5 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-200 disabled:bg-gray-200 dark:disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed hover:bg-red-200 dark:hover:bg-red-800 transition-colors"
            >
              <MinusIcon className="w-5 h-5" />
            </button>
            <span className="text-lg font-medium w-8 text-center text-gray-800 dark:text-gray-200">{cartQuantity}</span>
            <button
              onClick={() => onAddItem(product)}
              disabled={!canAdd}
              className="p-1.5 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-200 disabled:bg-gray-200 dark:disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
            >
              <PlusIcon className="w-5 h-5" />
            </button>
          </div>
          { !canAdd && cartQuantity > 0 && <span className="text-xs text-red-500">{t.maxStock}</span>}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
