
import React from 'react';
import { Product, TranslationSet } from '../types';
import { XMarkIcon } from './icons/XMarkIcon';
import InsightGenerator from './InsightGenerator';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';
import { WifiIcon } from './icons/WifiIcon';
import { EnvelopeIcon } from './icons/EnvelopeIcon';
import { PhoneIcon } from './icons/PhoneIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';


interface AdminPanelProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  onClose: () => void;
  t: TranslationSet;
  language: 'en' | 'es';
  customerEmail: string;
  setCustomerEmail: (email: string) => void;
  customerPhone: string;
  setCustomerPhone: (phone: string) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ products, setProducts, onClose, t, language, customerEmail, setCustomerEmail, customerPhone, setCustomerPhone }) => {
  const securityFeaturesList = ['AI Firewall', 'PCI DSS', 'NIST', 'CISA', 'PWA', 'CSP', 'CORS'];
  const securityProtections = ['Sniffing', 'Cloning', 'DDoS', 'Spoofing', 'Eavesdropping', 'XSS', 'Injection', 'Intrusion'];
  const connectedDevicesCount = 3; // Simulated for demonstration

  const handleCreateInvoice = () => {
    alert(t.invoiceCreated);
    // In a real app, this would trigger invoice generation and email sending
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-end z-50">
      <div className="w-full max-w-lg h-full bg-gray-100 dark:bg-gray-900 shadow-2xl flex flex-col transform transition-transform duration-300 translate-x-full animate-slide-in">
        <header className="p-4 bg-white dark:bg-gray-800 shadow-md flex justify-between items-center flex-shrink-0">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t.adminPanel}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <XMarkIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>
        </header>

        <div className="flex-grow p-6 overflow-y-auto">
          <div className="space-y-8">
            
            {/* Invoice & Customer Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">{t.invoiceAndCustomer}</h3>
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow space-y-4">
                <div className="relative">
                  <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-3 transform -translate-y-1/2" />
                  <input type="email" placeholder={t.customerEmail} value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-700 focus:ring-primary-500 focus:border-primary-500"/>
                </div>
                 <div className="relative">
                  <PhoneIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-3 transform -translate-y-1/2" />
                  <input type="tel" placeholder={t.customerPhone} value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-700 focus:ring-primary-500 focus:border-primary-500"/>
                </div>
                <button onClick={handleCreateInvoice} className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 disabled:bg-blue-400 transition-colors">
                  <DocumentTextIcon className="w-5 h-5 mr-2" />
                  <span>{t.createInvoice}</span>
                </button>
              </div>
            </div>

            {/* AI Insights Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">{t.businessInsights}</h3>
              <InsightGenerator products={products} t={t} language={language} />
            </div>

            {/* Network & Security Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">{t.networkAndSecurity}</h3>
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow space-y-4">
                 <div className="flex items-center text-gray-700 dark:text-gray-300">
                    <WifiIcon className="w-6 h-6 mr-3 text-primary-500" />
                    <span className="font-semibold">{t.connectedDevices}:</span>
                    <span className="ml-2 px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-sm font-bold rounded-full">{connectedDevicesCount} {t.devices}</span>
                 </div>
                 <div className="flex items-start text-gray-700 dark:text-gray-300">
                    <ShieldCheckIcon className="w-6 h-6 mr-3 mt-1 text-primary-500 flex-shrink-0" />
                    <div>
                      <span className="font-semibold">{t.securityFeatures}</span>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t.securityFeaturesBody}</p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {securityFeaturesList.map(feat => <span key={feat} className="px-2 py-0.5 text-xs bg-gray-200 dark:bg-gray-700 rounded-md">{feat}</span>)}
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-3 font-semibold">{t.authMethods}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Protection against: {securityProtections.join(', ')}.</p>
                    </div>
                 </div>
              </div>
            </div>

            {/* Product Management Section (Placeholder) */}
            <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">{t.manageProducts}</h3>
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
                 <p className="text-gray-600 dark:text-gray-400 text-sm">{t.manageProductsBody}</p>
              </div>
            </div>

             {/* User Management Section (Placeholder) */}
             <div>
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">{t.userManagement}</h3>
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
                 <p className="text-gray-600 dark:text-gray-400 text-sm">{t.userManagementBody}</p>
              </div>
            </div>

          </div>
        </div>
      </div>
      <style>{`
        @keyframes slide-in {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
        .animate-slide-in { animation: slide-in 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default AdminPanel;
