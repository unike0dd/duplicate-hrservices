
import React from 'react';
import { CartItemDetails, OrderDetails, TranslationSet } from '../types';

interface OrderSummaryProps {
  cartItems: CartItemDetails[];
  orderDetails: OrderDetails;
  onPay: () => void;
  t: TranslationSet;
}

const OrderSummary: React.FC<OrderSummaryProps> = ({ cartItems, orderDetails, onPay, t }) => {
  const { subtotal, tax, deliveryFee, total } = orderDetails;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 h-full flex flex-col">
      <h2 className="text-xl font-semibold mb-4 text-gray-700 dark:text-gray-300">{t.orderSummary}</h2>
      <div className="flex-grow overflow-y-auto pr-2">
        {cartItems.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center py-10">{t.emptyCart}</p>
        ) : (
          <ul className="space-y-3">
            {cartItems.map(item => (
              <li key={item.productId} className="flex justify-between items-center text-sm">
                <div className="flex-1">
                  <span className="font-semibold text-gray-800 dark:text-gray-200">{item.name}</span>
                  <span className="text-gray-500 dark:text-gray-400"> x {item.quantity}</span>
                </div>
                <span className="w-24 text-right font-medium text-gray-700 dark:text-gray-300">${(item.price * item.quantity).toFixed(2)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">{t.subtotal}</span>
          <span className="font-medium text-gray-800 dark:text-gray-200">${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">{t.taxes}</span>
          <span className="font-medium text-gray-800 dark:text-gray-200">${tax.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">{t.delivery}</span>
          <span className="font-medium text-gray-800 dark:text-gray-200">${deliveryFee.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-lg font-bold mt-2 pt-2 border-t border-gray-200 dark:border-gray-600">
          <span className="text-gray-900 dark:text-white">{t.total}</span>
          <span className="text-primary-600 dark:text-primary-400">${total.toFixed(2)}</span>
        </div>
      </div>
      <button
        onClick={onPay}
        disabled={cartItems.length === 0}
        className="w-full mt-6 py-3 px-4 bg-primary-600 text-white font-bold rounded-lg shadow-md hover:bg-primary-700 disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
      >
        {t.pay} ${total.toFixed(2)}
      </button>
    </div>
  );
};

export default OrderSummary;
