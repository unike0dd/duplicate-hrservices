
import React from 'react';
import { Product, CartItem, TranslationSet } from '../types';
import ProductCard from './ProductCard';

interface ProductListProps {
  products: Product[];
  cart: Map<number, CartItem>;
  onAddItem: (product: Product) => void;
  onRemoveItem: (product: Product) => void;
  t: TranslationSet;
}

const ProductList: React.FC<ProductListProps> = ({ products, cart, onAddItem, onRemoveItem, t }) => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4 text-gray-700 dark:text-gray-300">{t.products}</h2>
      <div className="flex space-x-6 pb-4 overflow-x-auto" style={{ scrollbarWidth: 'thin' }}>
        {products.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            cartQuantity={cart.get(product.id)?.quantity ?? 0}
            onAddItem={onAddItem}
            onRemoveItem={onRemoveItem}
            t={t}
          />
        ))}
      </div>
    </div>
  );
};

export default ProductList;
