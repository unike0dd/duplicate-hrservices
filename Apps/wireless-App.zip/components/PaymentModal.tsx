
import React, { useState, useEffect } from 'react';
import { TranslationSet } from '../types';
import { XMarkIcon } from './icons/XMarkIcon';

interface PaymentModalProps {
  total: number;
  onClose: () => void;
  onSuccessfulPayment: () => void;
  t: TranslationSet;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ total, onClose, onSuccessfulPayment, t }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleConfirmPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      setTimeout(() => {
        onSuccessfulPayment();
      }, 1500); // Close modal after showing success message
    }, 2000); // Simulate processing time
  };

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0 animate-fade-in-scale">
        <div className="p-6 relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors">
            <XMarkIcon className="w-6 h-6" />
          </button>
          
          <div className="text-center">
            {isSuccess ? (
              <div className="py-12">
                <svg className="w-16 h-16 mx-auto text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h2 className="text-2xl font-bold mt-4 text-gray-900 dark:text-white">{t.paymentSuccessTitle}</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">{t.paymentSuccessBody}</p>
              </div>
            ) : (
              <>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t.paymentModalTitle}</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-2">{t.paymentModalBody}</p>
                
                <div className="my-6 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg inline-block">
                  <img src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=pay-total-${total.toFixed(2)}`} alt="QR Code" />
                </div>
                
                <div className="text-3xl font-extrabold text-primary-600 dark:text-primary-400 mb-6">
                  ${total.toFixed(2)}
                </div>

                <button
                  onClick={handleConfirmPayment}
                  disabled={isProcessing}
                  className="w-full py-3 px-4 bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 disabled:bg-green-400 disabled:cursor-wait transition-all flex items-center justify-center space-x-2"
                >
                  {isProcessing && (
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  )}
                  <span>{isProcessing ? t.paymentProcessing : t.paymentConfirm}</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in-scale {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in-scale { animation: fade-in-scale 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default PaymentModal;
