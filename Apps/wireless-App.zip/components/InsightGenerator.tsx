
import React, { useState, useCallback } from 'react';
import { Product, TranslationSet } from '../types';
import { generateBusinessInsights } from '../services/geminiService';
import { ChartBarIcon } from './icons/ChartBarIcon';

interface InsightGeneratorProps {
  products: Product[];
  t: TranslationSet;
  language: 'en' | 'es';
}

const InsightGenerator: React.FC<InsightGeneratorProps> = ({ products, t, language }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [insights, setInsights] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleGenerateInsights = useCallback(async () => {
    setIsLoading(true);
    setError('');
    setInsights('');
    try {
      // For this demo, we'll simulate sales data based on stock changes.
      // A real app would use actual order history.
      const productData = products.map(p => ({
        name: language === 'es' ? p.name_es : p.name,
        price: p.price,
        initialStock: p.stock + Math.floor(Math.random() * 10), // a fictional initial stock
        currentStock: p.stock,
      }));

      const insightsText = await generateBusinessInsights(JSON.stringify(productData, null, 2), language);
      setInsights(insightsText);
    } catch (e) {
      console.error(e);
      setError(t.insightsError);
    } finally {
      setIsLoading(false);
    }
  }, [products, language, t]);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
      <div className="flex flex-col items-start">
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {t.insightsGeneratorBody}
        </p>
        <button
          onClick={handleGenerateInsights}
          disabled={isLoading}
          className="flex items-center justify-center px-4 py-2 bg-primary-600 text-white font-semibold rounded-lg shadow-md hover:bg-primary-700 disabled:bg-primary-400 dark:disabled:bg-primary-800 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? (
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <ChartBarIcon className="w-5 h-5 mr-2" />
          )}
          <span>{isLoading ? t.analyzing : t.generateInsights}</span>
        </button>

        {error && <p className="mt-4 text-sm text-red-500">{error}</p>}
        
        {insights && (
          <div className="mt-6 w-full">
            <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">{t.analysisResults}</h4>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-md text-sm text-gray-700 dark:text-gray-300 prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: insights.replace(/\n/g, '<br />') }}>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default InsightGenerator;
