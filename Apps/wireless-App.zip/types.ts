
export interface Product {
  id: number;
  name: string;
  name_es: string;
  description: string;
  description_es: string;
  price: number;
  imageUrl: string;
  stock: number;
}

export interface CartItem {
  productId: number;
  quantity: number;
}

export interface CartItemDetails extends CartItem {
  name: string;
  price: number;
  description: string;
}

export interface OrderDetails {
  subtotal: number;
  tax: number;
  deliveryFee: number;
  total: number;
}

export type TranslationSet = {
  appTitle: string;
  products: string;
  maxStock: string;
  orderSummary: string;
  emptyCart: string;
  subtotal: string;
  taxes: string;
  delivery: string;
  total: string;
  pay: string;
  paymentModalTitle: string;
  paymentModalBody: string;
  paymentConfirm: string;
  paymentProcessing: string;
  paymentSuccessTitle: string;
  paymentSuccessBody: string;
  adminPanel: string;
  manageProducts: string;
  manageProductsBody: string;
  businessInsights: string;
  userManagement: string;
  userManagementBody: string;
  insightsGeneratorBody: string;
  generateInsights: string;
  analyzing: string;
  insightsError: string;
  analysisResults: string;
  networkAndSecurity: string;
  connectedDevices: string;
  devices: string;
  securityFeatures: string;
  securityFeaturesBody: string;
  authMethods: string;
  invoiceAndCustomer: string;
  customerEmail: string;
  customerPhone: string;
  createInvoice: string;
  invoiceCreated: string;
};

export type Translations = {
  en: TranslationSet;
  es: TranslationSet;
};
