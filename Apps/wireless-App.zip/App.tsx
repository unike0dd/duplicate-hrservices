
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Product, CartItem, TranslationSet } from './types';
import { MOCK_PRODUCTS, DELIVERY_FEE, TAX_RATE } from './constants';
import { translations } from './translations';
import ProductList from './components/ProductList';
import OrderSummary from './components/OrderSummary';
import PaymentModal from './components/PaymentModal';
import AdminPanel from './components/AdminPanel';
import { CogIcon } from './components/icons/CogIcon';
import { SunIcon } from './components/icons/SunIcon';
import { MoonIcon } from './components/icons/MoonIcon';

type Theme = 'light' | 'dark';
type Language = 'en' | 'es';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [cart, setCart] = useState<Map<number, CartItem>>(new Map());
  const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
  const [isAdminPanelOpen, setAdminPanelOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>('dark');
  const [language, setLanguage] = useState<Language>('en');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  const t: TranslationSet = useMemo(() => translations[language], [language]);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const toggleLanguage = () => {
    setLanguage(prevLang => (prevLang === 'en' ? 'es' : 'en'));
  };

  const handleAddItem = useCallback((product: Product) => {
    setCart(prevCart => {
      const newCart = new Map(prevCart);
      const existingItem = newCart.get(product.id);
      if (existingItem) {
        if (existingItem.quantity < product.stock) {
          newCart.set(product.id, { ...existingItem, quantity: existingItem.quantity + 1 });
        }
      } else {
        if (product.stock > 0) {
          newCart.set(product.id, { productId: product.id, quantity: 1 });
        }
      }
      return newCart;
    });
  }, []);

  const handleRemoveItem = useCallback((product: Product) => {
    setCart(prevCart => {
      const newCart = new Map(prevCart);
      const existingItem = newCart.get(product.id);
      if (existingItem) {
        if (existingItem.quantity > 1) {
          newCart.set(product.id, { ...existingItem, quantity: existingItem.quantity - 1 });
        } else {
          newCart.delete(product.id);
        }
      }
      return newCart;
    });
  }, []);

  const handleSuccessfulPayment = useCallback(() => {
    setCart(new Map());
    setCustomerEmail('');
    setCustomerPhone('');
    setPaymentModalOpen(false);
  }, []);
  
  const orderDetails = useMemo(() => {
    const cartItems = Array.from(cart.values());
    const subtotal = cartItems.reduce((acc, item) => {
      const product = products.find(p => p.id === item.productId);
      return acc + (product ? product.price * item.quantity : 0);
    }, 0);
    
    const tax = subtotal * TAX_RATE;
    const total = subtotal + tax + (cartItems.length > 0 ? DELIVERY_FEE : 0);

    return { subtotal, tax, total, deliveryFee: cartItems.length > 0 ? DELIVERY_FEE : 0 };
  }, [cart, products]);

  const cartWithDetails = useMemo(() => {
    return Array.from(cart.values()).map(item => {
      const product = products.find(p => p.id === item.productId);
      return {
        ...item,
        name: language === 'es' ? product?.name_es ?? 'Desconocido' : product?.name ?? 'Unknown',
        price: product?.price ?? 0,
        description: language === 'es' ? product?.description_es ?? '' : product?.description ?? ''
      };
    }).sort((a,b) => a.name.localeCompare(b.name));
  }, [cart, products, language]);


  return (
    <div className="min-h-screen font-sans text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-900 flex flex-col">
      <header className="p-4 bg-white dark:bg-gray-800 shadow-md flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center space-x-3">
            <svg className="w-8 h-8 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t.appTitle}</h1>
        </div>
        <div className="flex items-center space-x-2">
            <button
              onClick={toggleLanguage}
              className="p-2 w-12 text-sm font-bold rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors text-gray-600 dark:text-gray-300"
              aria-label="Toggle Language"
            >
              {language.toUpperCase()}
            </button>
            <button
                onClick={toggleTheme}
                className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                aria-label="Toggle Theme"
            >
                {theme === 'light' ? <MoonIcon className="w-6 h-6 text-gray-600" /> : <SunIcon className="w-6 h-6 text-gray-300" />}
            </button>
            <button
              onClick={() => setAdminPanelOpen(true)}
              className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              aria-label="Open Admin Panel"
            >
              <CogIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
            </button>
        </div>
      </header>
      
      <main className="flex-grow flex flex-col p-4 md:p-6 lg:p-8 overflow-hidden">
        <div className="flex-shrink-0 mb-6">
          <ProductList products={products} cart={cart} onAddItem={handleAddItem} onRemoveItem={handleRemoveItem} t={t} />
        </div>
        <div className="flex-grow">
          <OrderSummary 
            cartItems={cartWithDetails} 
            orderDetails={orderDetails} 
            onPay={() => setPaymentModalOpen(true)}
            t={t}
          />
        </div>
      </main>

      {isPaymentModalOpen && (
        <PaymentModal
          total={orderDetails.total}
          onClose={() => setPaymentModalOpen(false)}
          onSuccessfulPayment={handleSuccessfulPayment}
          t={t}
        />
      )}

      {isAdminPanelOpen && (
        <AdminPanel
          products={products}
          setProducts={setProducts}
          onClose={() => setAdminPanelOpen(false)}
          t={t}
          language={language}
          customerEmail={customerEmail}
          setCustomerEmail={setCustomerEmail}
          customerPhone={customerPhone}
          setCustomerPhone={setCustomerPhone}
        />
      )}
    </div>
  );
};

export default App;
