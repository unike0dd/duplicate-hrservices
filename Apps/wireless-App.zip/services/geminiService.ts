
import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available as an environment variable
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const prompts = {
  en: (salesData: string) => `
    You are a business intelligence analyst for small retail businesses. Based on the following sales data, provide actionable insights and trends.
    The data represents product information, including simulated sales based on stock changes.
    
    Data:
    ${salesData}

    Please provide your analysis focusing on:
    1.  **Top-Performing Products:** Identify which products are selling the most.
    2.  **Inventory Management:** Suggest which items may need restocking soon or are overstocked.
    3.  **Pricing & Bundling:** Offer suggestions for product bundling or price adjustments to increase sales.
    4.  **Overall Summary:** A brief, high-level summary of the business health based on this data.

    Present the output as a clean, easy-to-read summary. Use markdown for formatting, such as bolding and bullet points.
  `,
  es: (salesData: string) => `
    Eres un analista de inteligencia de negocios para pequeñas empresas minoristas. Basado en los siguientes datos de ventas, proporciona información y tendencias accionables.
    Los datos representan información de productos, incluyendo ventas simuladas basadas en cambios de stock.

    Datos:
    ${salesData}

    Por favor, proporciona tu análisis centrándote en:
    1.  **Productos con Mejor Rendimiento:** Identifica qué productos se venden más.
    2.  **Gestión de Inventario:** Sugiere qué artículos pueden necesitar reabastecimiento pronto o tienen exceso de stock.
    3.  **Precios y Paquetes:** Ofrece sugerencias para agrupar productos o ajustar precios para aumentar las ventas.
    4.  **Resumen General:** Un breve resumen de alto nivel sobre la salud del negocio basado en estos datos.

    Presenta el resultado como un resumen limpio y fácil de leer. Usa markdown para el formato, como negritas y viñetas.
  `
};


export async function generateBusinessInsights(salesData: string, language: 'en' | 'es'): Promise<string> {
  const model = 'gemini-2.5-flash';
  
  const prompt = prompts[language](salesData);

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating insights with Gemini API:", error);
    throw new Error("Failed to communicate with the Gemini API.");
  }
}
