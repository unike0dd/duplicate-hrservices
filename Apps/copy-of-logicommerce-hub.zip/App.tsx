import React from 'react';
import { HashRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import ClientDashboard from './pages/ClientDashboard';
import Storefront from './pages/Storefront';
import { CartProvider } from './context/CartContext';
import { Icon } from './components/common/Icon';

const App: React.FC = () => {
  return (
    <CartProvider>
      <HashRouter>
        <div className="min-h-screen bg-brand-background text-brand-text-primary">
          <header className="bg-white/80 backdrop-blur-lg shadow-soft sticky top-0 z-40">
            <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between h-16">
                <div className="flex items-center space-x-3">
                   <div className="bg-brand-primary p-2 rounded-lg">
                    <Icon name="logo" className="h-6 w-6 text-white" />
                   </div>
                  <span className="font-display font-bold text-xl text-brand-text-primary">LogiCommerce</span>
                </div>
                <div className="flex items-center space-x-1 bg-brand-secondary p-1 rounded-full">
                  <NavLink
                    to="/dashboard"
                    className={({ isActive }) =>
                      `px-4 py-1.5 text-sm font-semibold rounded-full flex items-center gap-2 transition-colors duration-300 ${isActive 
                        ? 'bg-brand-primary text-white shadow' 
                        : 'text-brand-text-secondary hover:text-brand-primary'
                      }`
                    }
                  >
                     <Icon name="dashboard" className="h-5 w-5" /> Client View
                  </NavLink>
                  <NavLink
                    to="/store"
                     className={({ isActive }) =>
                      `px-4 py-1.5 text-sm font-semibold rounded-full flex items-center gap-2 transition-colors duration-300 ${isActive 
                        ? 'bg-brand-primary text-white shadow' 
                        : 'text-brand-text-secondary hover:text-brand-primary'
                      }`
                    }
                  >
                     <Icon name="store" className="h-5 w-5" /> Consumer Store
                  </NavLink>
                </div>
              </div>
            </nav>
          </header>

          <main>
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<ClientDashboard />} />
              <Route path="/store" element={<Storefront />} />
            </Routes>
          </main>
           <footer className="text-center py-6 mt-8 text-brand-text-secondary text-sm">
              <p>LogiCommerce Hub &copy; {new Date().getFullYear()}. A secure e-commerce logistics platform.</p>
               <p className="text-gray-400 text-xs mt-1">PCI DSS, NIST, CISA, PWA, CSP, CORS Compliant Simulation</p>
            </footer>
        </div>
      </HashRouter>
    </CartProvider>
  );
};

export default App;