
import { Product, Order, Courier, FinancialMetric, CustomerReview } from './types';

export const MOCK_PRODUCTS: Product[] = [
  { id: 1, name: 'Logistics Box A', category: 'Packaging', price: 12.99, imageUrl: 'https://picsum.photos/seed/product1/400/400', stock: 150, buyPrice: 7.50 },
  { id: 2, name: 'Heavy-Duty Tape', category: 'Supplies', price: 5.49, imageUrl: 'https://picsum.photos/seed/product2/400/400', stock: 300, buyPrice: 2.10 },
  { id: 3, name: 'GPS Tracking Unit', category: 'Electronics', price: 89.99, imageUrl: 'https://picsum.photos/seed/product3/400/400', stock: 50, buyPrice: 55.00 },
  { id: 4, name: 'Fleet Management Software', category: 'Software', price: 499.99, imageUrl: 'https://picsum.photos/seed/product4/400/400', stock: 20, buyPrice: 300.00 },
  { id: 5, name: 'Protective Bubble Wrap', category: 'Packaging', price: 25.00, imageUrl: 'https://picsum.photos/seed/product5/400/400', stock: 120, buyPrice: 15.00 },
  { id: 6, name: 'Handheld Scanner', category: 'Electronics', price: 150.00, imageUrl: 'https://picsum.photos/seed/product6/400/400', stock: 75, buyPrice: 90.00 },
];

export const MOCK_ORDERS: Order[] = [
  { id: 'ORD-2401A', customerName: 'Global Corp', items: [{productId: 1, quantity: 10}, {productId:2, quantity: 20}], total: 239.70, status: 'In Transit', deliveryLocation: { lat: 34.0522, lng: -118.2437 }, courierId: 1, date: '2024-07-20' },
  { id: 'ORD-2402B', customerName: 'Innovate LLC', items: [{productId: 3, quantity: 2}], total: 179.98, status: 'Processing', deliveryLocation: { lat: 34.0600, lng: -118.2500 }, date: '2024-07-21' },
  { id: 'ORD-2403C', customerName: 'Local Biz', items: [{productId: 5, quantity: 5}], total: 125.00, status: 'Delivered', deliveryLocation: { lat: 34.0450, lng: -118.2300 }, courierId: 2, date: '2024-07-19' },
  { id: 'ORD-2404D', customerName: 'Tech Solutions', items: [{productId: 4, quantity: 1}, {productId: 6, quantity: 5}], total: 1249.99, status: 'In Transit', deliveryLocation: { lat: 34.0555, lng: -118.2650 }, courierId: 3, date: '2024-07-21' },
];

export const MOCK_COURIERS: Courier[] = [
    { id: 1, name: 'John D.', vehicle: 'Van', location: { lat: 34.0522, lng: -118.2437 } },
    { id: 2, name: 'Maria S.', vehicle: 'Motorcycle', location: { lat: 34.0450, lng: -118.2300 } },
    { id: 3, name: 'Chen W.', vehicle: 'Truck', location: { lat: 34.0555, lng: -118.2650 } }
];

export const MOCK_FINANCIAL_METRICS: FinancialMetric[] = [
    { label: 'Total Revenue', value: '$15,430.50', change: '+5.2%', changeType: 'increase' },
    { label: 'Net Profit', value: '$4,880.10', change: '+2.1%', changeType: 'increase' },
    { label: 'Taxes Collected', value: '$1,388.75', change: '+4.8%', changeType: 'increase' },
    { label: 'Operational Costs', value: '$2,150.00', change: '-1.5%', changeType: 'decrease' },
];

export const MOCK_CUSTOMER_REVIEWS: CustomerReview[] = [
    { id: 1, name: 'Alice', review: "The delivery was incredibly fast and the tracking was spot on. I'm very impressed with the service!" },
    { id: 2, name: 'Bob', review: "My package arrived a day late and the box was slightly damaged. Not the best experience." },
    { id: 3, name: 'Charlie', review: "It was an okay service. The product is fine, but nothing stood out as exceptional." },
    { id: 4, name: 'Diana', review: "Absolutely fantastic! The driver was courteous, and the entire process from order to delivery was seamless. Will definitely use again." },
];
