
export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  imageUrl: string;
  stock: number;
  buyPrice: number;
}

export type OrderStatus = 'Processing' | 'In Transit' | 'Delivered' | 'Cancelled';

export interface Order {
  id: string;
  customerName: string;
  items: { productId: number; quantity: number }[];
  total: number;
  status: OrderStatus;
  deliveryLocation: { lat: number; lng: number };
  courierId?: number;
  date: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Courier {
    id: number;
    name: string;
    vehicle: 'Truck' | 'Van' | 'Motorcycle';
    location: { lat: number; lng: number };
}

export interface FinancialMetric {
    label: string;
    value: string;
    change?: string;
    changeType?: 'increase' | 'decrease';
}

export interface CustomerReview {
  id: number;
  name: string;
  review: string;
}

export interface SentimentAnalysisResult {
  sentiment: 'Positive' | 'Negative' | 'Neutral';
  summary: string;
}
