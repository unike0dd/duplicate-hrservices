
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { CustomerReview, SentimentAnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully,
  // but for this example, we'll throw an error if the key is missing.
  console.warn("API_KEY environment variable not set. Gemini features will not work.");
}

// Initialize with a check for API_KEY to avoid crashing if it's not set.
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const sentimentSchema = {
  type: Type.OBJECT,
  properties: {
    sentiment: {
      type: Type.STRING,
      description: 'The sentiment of the review. Must be one of: "Positive", "Negative", or "Neutral".',
      enum: ["Positive", "Negative", "Neutral"]
    },
    summary: {
      type: Type.STRING,
      description: 'A brief one-sentence summary of the review.',
    },
  },
  required: ["sentiment", "summary"],
};


export const analyzeSentiment = async (review: CustomerReview): Promise<SentimentAnalysisResult> => {
  if (!ai) {
    // Simulate a successful response for UI development if API key is not available
    console.warn("Gemini API key not found. Returning mock sentiment data.");
    const sentiments: SentimentAnalysisResult['sentiment'][] = ['Positive', 'Negative', 'Neutral'];
    return {
      sentiment: sentiments[Math.floor(Math.random() * sentiments.length)],
      summary: "This is a mock analysis as the API key is not configured."
    };
  }
  
  const prompt = `Analyze the sentiment of the following customer review and provide a one-sentence summary. Review from ${review.name}: "${review.review}"`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: sentimentSchema,
      },
    });

    const jsonString = response.text;
    const result = JSON.parse(jsonString);
    
    // Basic validation
    if (result && typeof result.sentiment === 'string' && typeof result.summary === 'string') {
        return result as SentimentAnalysisResult;
    } else {
        throw new Error('Invalid JSON structure received from API.');
    }

  } catch (error) {
    console.error("Error analyzing sentiment with Gemini API:", error);
    throw new Error("Failed to analyze sentiment. Please check the console for more details.");
  }
};
