import React, { useState } from 'react';
import { Icon } from '../components/common/Icon';
import DispatchMap from '../components/dashboard/DispatchMap';
import InventoryList from '../components/dashboard/InventoryList';
import OrderList from '../components/dashboard/OrderList';
import AccountingSummary from '../components/dashboard/AccountingSummary';
import SentimentAnalysis from '../components/dashboard/SentimentAnalysis';

type Tab = 'dispatch' | 'inventory' | 'orders' | 'finance';

const ClientDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('dispatch');

  const renderContent = () => {
    const contentMap = {
      dispatch: <DispatchMap />,
      inventory: <InventoryList />,
      orders: <OrderList />,
      finance: (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 animate-fade-in">
            <div className="xl:col-span-3">
                <AccountingSummary />
            </div>
            <div className="xl:col-span-3">
                <SentimentAnalysis />
            </div>
        </div>
      ),
    };
    return <div className="animate-fade-in">{contentMap[activeTab]}</div>;
  };

  const TabButton = ({ tab, label, iconName }: { tab: Tab, label: string, iconName: string }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center space-x-3 px-4 py-3 text-sm font-semibold rounded-lg transition-all duration-300 ${
        activeTab === tab 
          ? 'bg-brand-secondary text-brand-primary shadow-soft' 
          : 'text-brand-text-secondary hover:bg-gray-100 hover:text-brand-text-primary'
      }`}
    >
      <Icon name={iconName} className="h-5 w-5" />
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <div className="bg-white rounded-2xl shadow-lifted overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="p-2 sm:p-3 flex space-x-1 sm:space-x-2" aria-label="Tabs">
            <TabButton tab="dispatch" label="Dispatch Console" iconName="map" />
            <TabButton tab="inventory" label="Inventory" iconName="inventory" />
            <TabButton tab="orders" label="Orders" iconName="orders" />
            <TabButton tab="finance" label="Finance & Analytics" iconName="finance" />
          </nav>
        </div>
        <div className="p-4 sm:p-6 bg-brand-background/50 min-h-[60vh]">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;
