import React, { useState } from 'react';
import { MOCK_PRODUCTS } from '../constants';
import ProductCard from '../components/store/ProductCard';
import { useCart } from '../context/CartContext';
import { Icon } from '../components/common/Icon';
import CheckoutModal from '../components/store/CheckoutModal';
import TrackOrderModal from '../components/store/TrackOrderModal';

const Storefront: React.FC = () => {
    const { totalItems } = useCart();
    const [isCheckoutOpen, setCheckoutOpen] = useState(false);
    const [isTrackOrderOpen, setTrackOrderOpen] = useState(false);

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8 h-[calc(100vh-8rem)] flex flex-col">
            <div className="flex-shrink-0 flex justify-between items-center mb-6">
                <div>
                    <h1 className="font-display text-4xl font-bold text-brand-text-primary">Our Products</h1>
                    <p className="text-brand-text-secondary mt-1">Everything your logistics business needs, delivered.</p>
                </div>
                <button 
                    onClick={() => setCheckoutOpen(true)}
                    className="relative bg-brand-primary text-white px-5 py-3 rounded-full shadow-lg hover:bg-brand-primary-dark transition-all duration-300 hover:scale-105 flex items-center gap-2 font-semibold"
                >
                    <Icon name="cart" className="h-5 w-5" />
                    <span className="hidden sm:inline">View Cart</span>
                    {totalItems > 0 && (
                        <span className="absolute -top-1 -right-1 bg-brand-accent text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center ring-2 ring-white">
                            {totalItems}
                        </span>
                    )}
                </button>
            </div>
            
            <div className="my-2 text-center">
                <button
                    onClick={() => setTrackOrderOpen(true)}
                    className="bg-brand-highlight text-white px-6 py-3 rounded-full font-semibold shadow-lg hover:bg-brand-highlight-dark transition-all duration-300 hover:scale-105 flex items-center gap-2 mx-auto"
                >
                    <Icon name="truck" className="h-5 w-5" />
                    Track Your Order
                </button>
            </div>

            <div className="flex-grow overflow-y-auto pr-2 -mr-2 mt-4">
                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6 animate-fade-in">
                    {MOCK_PRODUCTS.map((product) => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
            
            <CheckoutModal isOpen={isCheckoutOpen} onClose={() => setCheckoutOpen(false)} />
            <TrackOrderModal isOpen={isTrackOrderOpen} onClose={() => setTrackOrderOpen(false)} />

        </div>
    );
};

export default Storefront;