import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`bg-white rounded-xl shadow-soft p-4 sm:p-6 transition-all duration-300 hover:shadow-lifted hover:-translate-y-1 ${className}`}>
      {children}
    </div>
  );
};

export default Card;
