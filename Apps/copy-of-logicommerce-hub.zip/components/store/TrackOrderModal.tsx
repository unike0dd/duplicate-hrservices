import React, { useState } from 'react';
import { Icon } from '../common/Icon';
import { MOCK_ORDERS } from '../../constants';
import { Order } from '../../types';

interface TrackOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TrackOrderModal: React.FC<TrackOrderModalProps> = ({ isOpen, onClose }) => {
  const [orderId, setOrderId] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<Order | null | undefined>(undefined); // undefined: not searched, null: not found

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    const foundOrder = MOCK_ORDERS.find(o => o.id.toLowerCase() === orderId.toLowerCase().trim());
    setTrackedOrder(foundOrder || null);
  };

  const handleClose = () => {
    setOrderId('');
    setTrackedOrder(undefined);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-fade-in" onClick={handleClose}>
      <div className="bg-white rounded-2xl shadow-lifted w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden animate-slide-up" onClick={(e) => e.stopPropagation()}>
        <header className="flex justify-between items-center p-5 border-b border-gray-200">
          <h2 className="font-display text-2xl font-bold text-brand-primary">Track Your Order</h2>
          <button onClick={handleClose} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-colors">
            <Icon name="close" className="h-6 w-6" />
          </button>
        </header>
        
        <form onSubmit={handleTrack} className="p-6">
          <p className="text-sm text-brand-text-secondary mb-4">Enter your Order ID below to see its status.</p>
          <div className="flex items-center gap-2">
            <input 
              type="text"
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="e.g., ORD-2401A"
              className="p-2 border border-gray-300 rounded-md w-full focus:ring-2 focus:ring-brand-primary focus:border-brand-primary"
              required
            />
            <button type="submit" className="bg-brand-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-brand-primary-dark transition-colors">
              Track
            </button>
          </div>
        </form>

        <div className="p-6 pt-0">
          {trackedOrder === undefined && (
            <div className="text-center text-gray-400 py-6">
              <p>Waiting for you to enter an order ID.</p>
            </div>
          )}
          {trackedOrder === null && (
            <div className="text-center text-brand-danger bg-brand-danger-light p-4 rounded-lg">
              <p className="font-semibold">Order Not Found</p>
              <p className="text-sm">Please check the Order ID and try again.</p>
            </div>
          )}
          {trackedOrder && (
            <div className="border border-gray-200 bg-gray-50 p-4 rounded-lg space-y-2 animate-fade-in">
                <div className="flex justify-between items-center"><span className="font-semibold text-brand-text-secondary">Order ID:</span> <span className="font-mono">{trackedOrder.id}</span></div>
                <div className="flex justify-between items-center"><span className="font-semibold text-brand-text-secondary">Customer:</span> <span>{trackedOrder.customerName}</span></div>
                <div className="flex justify-between items-center"><span className="font-semibold text-brand-text-secondary">Status:</span> 
                  <span className="font-bold text-brand-primary">{trackedOrder.status}</span>
                </div>
                {trackedOrder.status === 'In Transit' && trackedOrder.courierId && (
                     <div className="flex justify-between items-center"><span className="font-semibold text-brand-text-secondary">Courier ID:</span> <span>{trackedOrder.courierId}</span></div>
                )}
                 {trackedOrder.status === 'Delivered' && (
                     <p className="text-brand-success font-semibold pt-2 text-center">Your order has been delivered!</p>
                )}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default TrackOrderModal;