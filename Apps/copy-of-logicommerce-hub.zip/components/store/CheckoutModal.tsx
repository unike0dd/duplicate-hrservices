import React from 'react';
import { useCart } from '../../context/CartContext';
import { Icon } from '../common/Icon';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const { cart, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart();
  const deliveryCharge = 15.00;
  const taxes = totalPrice * 0.08;
  const total = totalPrice + deliveryCharge + taxes;

  if (!isOpen) return null;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your order! Your delivery is on its way. (This is a simulation)');
    clearCart();
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-lifted w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-slide-up" onClick={(e) => e.stopPropagation()}>
        <header className="flex justify-between items-center p-5 border-b border-gray-200 flex-shrink-0">
          <h2 className="font-display text-2xl font-bold text-brand-text-primary">Your Cart</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-colors">
            <Icon name="close" className="h-6 w-6" />
          </button>
        </header>
        
        <div className="p-6 overflow-y-auto flex-grow">
          {cart.length === 0 ? (
            <div className="text-center text-gray-500 py-10">
              <Icon name="cart" className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="font-semibold text-lg">Your cart is empty.</h3>
              <p className="text-sm">Looks like you haven't added anything yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between py-4">
                  <div className="flex items-center gap-4">
                    <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-lg shadow-sm"/>
                    <div>
                      <p className="font-semibold text-brand-text-primary">{item.name}</p>
                      <p className="text-sm text-brand-text-secondary">${item.price.toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <input 
                      type="number"
                      value={item.quantity}
                      onChange={(e) => updateQuantity(item.id, parseInt(e.target.value, 10))}
                      className="w-16 text-center border border-gray-300 rounded-md focus:ring-2 focus:ring-brand-primary focus:border-brand-primary"
                      min="1"
                    />
                    <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-50 transition-colors">
                      <Icon name="trash" className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {cart.length > 0 && (
          <footer className="p-6 border-t border-gray-200 bg-gray-50 flex-shrink-0">
            <form onSubmit={handleCheckout}>
              <div className="space-y-2 mb-4 text-brand-text-secondary">
                  <div className="flex justify-between text-sm"><span>Subtotal</span><span className="font-medium text-brand-text-primary">${totalPrice.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span>Delivery Charge</span><span>${deliveryCharge.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span>Taxes (8%)</span><span>${taxes.toFixed(2)}</span></div>
                  <hr className="my-2"/>
                  <div className="flex justify-between font-bold text-lg text-brand-text-primary"><span>Total</span><span>${total.toFixed(2)}</span></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <input type="email" placeholder="Email for Invoice" className="p-2 border border-gray-300 rounded-md w-full focus:ring-2 focus:ring-brand-primary focus:border-brand-primary" required />
                  <input type="tel" placeholder="Phone for Notifications" className="p-2 border border-gray-300 rounded-md w-full focus:ring-2 focus:ring-brand-primary focus:border-brand-primary" required />
              </div>
              <button type="submit" className="w-full bg-brand-success text-white py-3 rounded-lg font-bold hover:bg-brand-success-dark transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                Proceed to Checkout
              </button>
              <p className="text-xs text-center text-gray-500 mt-2">You will be redirected to a secure payment gateway.</p>
            </form>
          </footer>
        )}
      </div>
    </div>
  );
};

export default CheckoutModal;