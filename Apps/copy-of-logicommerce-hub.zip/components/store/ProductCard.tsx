import React from 'react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import Card from '../common/Card';
import { Icon } from '../common/Icon';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();

  return (
    <Card className="flex flex-col group overflow-hidden">
      <div className="relative">
        <img src={product.imageUrl} alt={product.name} className="w-full h-48 object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-110" />
        <div className="absolute top-3 right-3 bg-brand-secondary text-brand-primary text-xs px-2.5 py-1 rounded-full font-semibold">{product.category}</div>
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="font-display text-lg font-bold text-brand-text-primary flex-grow">{product.name}</h3>
        <p className="font-display text-3xl font-bold text-brand-primary mt-2">${product.price.toFixed(2)}</p>
      </div>
      <div className="p-4 pt-0">
        <button 
          onClick={() => addToCart(product)}
          className="w-full bg-brand-primary text-white py-2.5 rounded-lg hover:bg-brand-primary-dark transition-colors flex items-center justify-center gap-2 font-semibold transform-gpu group-hover:scale-105 duration-300"
        >
          <Icon name="cart" className="h-5 w-5" />
          Add to Cart
        </button>
      </div>
    </Card>
  );
};

export default ProductCard;