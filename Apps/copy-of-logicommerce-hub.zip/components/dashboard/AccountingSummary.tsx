
import React from 'react';
import Card from '../common/Card';
import { MOCK_FINANCIAL_METRICS } from '../../constants';
import { FinancialMetric } from '../../types';

const MetricCard: React.FC<{ metric: FinancialMetric }> = ({ metric }) => (
    <Card className="flex-1">
        <p className="text-sm text-brand-text-secondary font-medium">{metric.label}</p>
        <div className="flex items-baseline space-x-2 mt-1">
            <p className="text-2xl font-bold text-brand-primary">{metric.value}</p>
            {metric.change && (
                <span className={`text-sm font-semibold ${metric.changeType === 'increase' ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {metric.change}
                </span>
            )}
        </div>
    </Card>
);

const AccountingSummary: React.FC = () => {
  return (
    <div>
        <h2 className="text-xl font-bold text-brand-primary mb-4">Financial Overview</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {MOCK_FINANCIAL_METRICS.map((metric, index) => (
                <MetricCard key={index} metric={metric} />
            ))}
        </div>
    </div>
  );
};

export default AccountingSummary;