
import React from 'react';
import Card from '../common/Card';
import { MOCK_ORDERS, MOCK_COURIERS } from '../../constants';
import { Icon } from '../common/Icon';

const DispatchMap: React.FC = () => {

  const orderLocations = MOCK_ORDERS.filter(o => o.status === 'In Transit' || o.status === 'Processing').map(order => ({
    id: order.id,
    ...order.deliveryLocation,
    type: 'pickup'
  }));
  
  const courierLocations = MOCK_COURIERS.map(courier => ({
    id: courier.id,
    ...courier.location,
    vehicle: courier.vehicle.toLowerCase()
  }));

  // These positions are percentages relative to the container size,
  // representing a simplified mapping from lat/lng.
  const getPosition = (lat: number, lng: number) => {
    const latMin = 34.040, latMax = 34.065;
    const lngMin = -118.270, lngMax = -118.225;
    const top = 100 - ((lat - latMin) / (latMax - latMin)) * 100;
    const left = ((lng - lngMin) / (lngMax - lngMin)) * 100;
    return { top: `${top}%`, left: `${left}%` };
  };

  return (
    <Card className="h-full">
      <h2 className="text-xl font-bold text-brand-primary mb-4">Live Dispatch Console</h2>
      <div className="relative w-full h-[500px] bg-gray-300 rounded-lg overflow-hidden">
        <img src="https://picsum.photos/seed/map/1200/800" alt="City map" className="w-full h-full object-cover" />
        
        {/* Render Order Locations */}
        {orderLocations.map(loc => {
          const {top, left} = getPosition(loc.lat, loc.lng);
          return (
            <div key={loc.id} className="absolute transform -translate-x-1/2 -translate-y-1/2" style={{ top, left }}>
              <div className="group relative">
                  <Icon name="orders" className="h-7 w-7 text-brand-danger" />
                  <div className="absolute bottom-full mb-2 w-max px-2 py-1 text-xs text-white bg-brand-primary rounded opacity-0 group-hover:opacity-100 transition-opacity">
                      Order: {loc.id}
                  </div>
              </div>
            </div>
          )
        })}
        
        {/* Render Courier Locations */}
        {courierLocations.map(loc => {
           const {top, left} = getPosition(loc.lat, loc.lng);
           return (
            <div key={`c-${loc.id}`} className="absolute transform -translate-x-1/2 -translate-y-1/2" style={{ top, left }}>
               <div className="group relative">
                  <div className="bg-brand-primary p-1 rounded-full shadow-lg">
                      <Icon name={loc.vehicle} className="h-5 w-5 text-white" />
                  </div>
                  <div className="absolute bottom-full mb-2 w-max px-2 py-1 text-xs text-white bg-brand-primary rounded opacity-0 group-hover:opacity-100 transition-opacity">
                      Courier: {loc.id} ({loc.vehicle})
                  </div>
               </div>
            </div>
           )
        })}
      </div>
    </Card>
  );
};

export default DispatchMap;
