
import React, { useState, useCallback } from 'react';
import Card from '../common/Card';
import { MOCK_CUSTOMER_REVIEWS } from '../../constants';
import { CustomerReview, SentimentAnalysisResult } from '../../types';
import { analyzeSentiment } from '../../services/geminiService';

interface AnalysisState {
  [key: number]: {
    loading: boolean;
    result?: SentimentAnalysisResult;
    error?: string;
  };
}

const SentimentAnalysis: React.FC = () => {
  const [analysis, setAnalysis] = useState<AnalysisState>({});

  const handleAnalyze = useCallback(async (review: CustomerReview) => {
    setAnalysis(prev => ({
      ...prev,
      [review.id]: { loading: true }
    }));

    try {
      const result = await analyzeSentiment(review);
      setAnalysis(prev => ({
        ...prev,
        [review.id]: { loading: false, result }
      }));
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setAnalysis(prev => ({
        ...prev,
        [review.id]: { loading: false, error: errorMessage }
      }));
    }
  }, []);
  
  const getSentimentClasses = (sentiment?: SentimentAnalysisResult['sentiment']) => {
      switch (sentiment) {
          case 'Positive': return 'bg-brand-success text-white';
          case 'Negative': return 'bg-brand-danger text-white';
          case 'Neutral': return 'bg-brand-warning text-white';
          default: return 'bg-gray-200 text-gray-800';
      }
  }

  return (
    <Card>
      <h2 className="text-xl font-bold text-brand-primary mb-4">Customer Sentiment Analysis (Powered by Gemini)</h2>
      <div className="space-y-4">
        {MOCK_CUSTOMER_REVIEWS.map((review) => (
          <div key={review.id} className="p-4 border border-gray-200 rounded-lg bg-gray-50">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold text-brand-primary">{review.name}</p>
                <p className="text-sm text-brand-text-secondary italic">"{review.review}"</p>
              </div>
              <button
                onClick={() => handleAnalyze(review)}
                disabled={analysis[review.id]?.loading}
                className="ml-4 px-3 py-1.5 text-xs font-semibold text-white bg-brand-primary rounded-md hover:bg-brand-primary-dark transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {analysis[review.id]?.loading ? 'Analyzing...' : 'Analyze'}
              </button>
            </div>
            {analysis[review.id] && !analysis[review.id]?.loading && (
              <div className="mt-3 p-3 rounded-md bg-white border">
                {analysis[review.id]?.error && (
                  <p className="text-sm text-red-600">Error: {analysis[review.id]?.error}</p>
                )}
                {analysis[review.id]?.result && (
                  <div className="flex items-center gap-4">
                     <span className={`px-3 py-1 text-sm font-bold rounded-full ${getSentimentClasses(analysis[review.id]?.result?.sentiment)}`}>
                        {analysis[review.id]?.result?.sentiment}
                     </span>
                     <p className="text-sm text-gray-700">{analysis[review.id]?.result?.summary}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default SentimentAnalysis;