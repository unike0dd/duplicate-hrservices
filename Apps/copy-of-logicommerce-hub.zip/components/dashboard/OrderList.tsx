import React from 'react';
import Card from '../common/Card';
import { MOCK_ORDERS } from '../../constants';
import { OrderStatus } from '../../types';

const getStatusClasses = (status: OrderStatus) => {
  switch (status) {
    case 'Delivered':
      return 'bg-brand-success-light text-brand-success';
    case 'In Transit':
      return 'bg-brand-info-light text-brand-info';
    case 'Processing':
      return 'bg-brand-warning-light text-brand-warning';
    case 'Cancelled':
      return 'bg-brand-danger-light text-brand-danger';
    default:
      return 'bg-gray-100 text-gray-700';
  }
};

const OrderList: React.FC = () => {
  return (
    <Card>
      <h2 className="font-display text-xl font-bold text-brand-text-primary mb-4">Recent Orders</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-brand-text-secondary uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 font-semibold">Order ID</th>
              <th scope="col" className="px-6 py-3 font-semibold">Customer</th>
              <th scope="col" className="px-6 py-3 font-semibold">Date</th>
              <th scope="col" className="px-6 py-3 font-semibold">Total</th>
              <th scope="col" className="px-6 py-3 font-semibold">Status</th>
              <th scope="col" className="px-6 py-3 font-semibold text-center">Courier ID</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {MOCK_ORDERS.map((order) => (
              <tr key={order.id} className="hover:bg-gray-50/50">
                <td className="px-6 py-4 font-mono text-gray-700">{order.id}</td>
                <td className="px-6 py-4 font-medium text-brand-text-primary">{order.customerName}</td>
                <td className="px-6 py-4 text-brand-text-secondary">{order.date}</td>
                <td className="px-6 py-4 font-semibold text-brand-text-primary">${order.total.toFixed(2)}</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClasses(order.status)}`}>
                    {order.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-center text-brand-text-secondary">{order.courierId || 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

export default OrderList;