
import React from 'react';
import Card from '../common/Card';
import { MOCK_PRODUCTS } from '../../constants';

const InventoryList: React.FC = () => {
  return (
    <Card>
      <h2 className="text-xl font-bold text-brand-primary mb-4">Inventory Management</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3">Product Name</th>
              <th scope="col" className="px-6 py-3">Category</th>
              <th scope="col" className="px-6 py-3">Stock</th>
              <th scope="col" className="px-6 py-3">Buy Price</th>
              <th scope="col" className="px-6 py-3">Sell Price</th>
              <th scope="col" className="px-6 py-3">Profit Margin</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PRODUCTS.map((product) => {
              const profit = product.price - product.buyPrice;
              const margin = (profit / product.price) * 100;
              return (
                <tr key={product.id} className="bg-white border-b hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{product.name}</td>
                  <td className="px-6 py-4">{product.category}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${product.stock > 50 ? 'bg-brand-success-light text-brand-success' : 'bg-brand-danger-light text-brand-danger'}`}>
                      {product.stock} units
                    </span>
                  </td>
                  <td className="px-6 py-4">${product.buyPrice.toFixed(2)}</td>
                  <td className="px-6 py-4">${product.price.toFixed(2)}</td>
                  <td className="px-6 py-4 text-brand-success">{margin.toFixed(1)}%</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

export default InventoryList;